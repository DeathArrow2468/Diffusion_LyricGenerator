Diffusion_Lyrics technical report

Compile main.tex using pdfLaTeX (twice), or latexmk -pdf main.tex.
No BibTeX, shell escape, external images, or model downloads are required.
The TikZ figure is editable directly in chapters/03_methodology.tex.

Files are segregated by the supplied chapter structure:
00_frontmatter: abbreviations and notations
01_introduction: sections 1.1-1.7
02_background: sections 2.1-2.4
03_methodology: sections 3.1-3.3, with detailed technical subsections
04_results: headings only; content intentionally blank
05_conclusion: sections 5.1-5.4
appendix_a: core source excerpt and file responsibilities
appendix_b: provenance and reconciliation notes
references.tex: bibliography

No internship letter or plagiarism report is included.
Replace the generic cover only after the official title, institution, authors,
guide and submission details are supplied. Section 1.5 is an undated work
sequence because actual project dates were not available.

Authoritative repository commit:
f78f1733e6e1b8a290cbfed10eff997671f2f9c8
Inspected 10 November 2026.

The report describes source code; it does not claim model training or GPU
inference was run during report preparation. The dataset file in the checkout
was a Git LFS pointer, so corpus statistics are not asserted.
